import './ItemsList.css'

function ItemsList(props) {

    const rows = props.categories.map(category => {
        const categoryItems = props.items.filter(item => item.category_id === category._id).map(item => (
          <div className="col-3 item-card-container" key={item.name}>
            <div className="item-card" onClick={() => props.onItemClick(item)}>{item.name}</div>
            </div>
        ))
        if(categoryItems.length === 0) return <></>
        return <><div className="col-12 items-list-category" key={category.name}><h5>{category.name}</h5></div> {categoryItems}</>
    })

    return (<div>
        <span style={{fontSize: "30px", width: "60%", display: "inline-block"}}><span style={{color: "#f9a109"}}>Shoppingify</span> allows you to take your shopping list wherever you go</span>
        
        <div class="form-group" style={{float: 'right', paddingLeft: '50px'}}>
        <div class="input-group mb-2">
        <div class="input-group-prepend">
          <div class="input-group-text" style={{backgroundColor: 'white'}}><i class="fas fa-search"></i></div>
        </div>
        <input type="text" class="form-control" id="inlineFormInputGroup" placeholder="Search Item"/>
      </div>
      </div>

      <div className="row"> {rows} </div>
    </div>)
}

export default ItemsList