import {useEffect, useState} from 'react'
import LeftMenu from '../../components/left-menu/LeftMenu'
import ItemsList from '../items-list/ItemsList'
import CategoriesService from '../../services/CategoriesService'
import ItemsService from '../../services/ItemsService'
import AddItemForm from '../../components/right-section/add-item-form/AddItemForm'
import ActiveList from '../../components/right-section/active-list/ActiveList'
import ItemDetails from '../../components/right-section/item-details/ItemDetails'

import './Home.css'

function Home(props) {

    let [categories, setCategories] = useState([])
    let [items, setItems] = useState([])
    let [itemsChanged, setItemsChanged] = useState(false)
    let [clickedItem, setClickedItem] = useState(null)

    let [selectedSidePage, setSelectedSidePage] = useState(0)
    let [selectedPage, setSelectedPage] = useState(0)

    function reloadItems() {
        setItemsChanged(!itemsChanged)
    }

    useEffect(() => {
        CategoriesService.get().then(res => {
            setCategories(res.data)
        })

        ItemsService.get().then(res => {
            setItems(res.data)
        })
    }, [itemsChanged])

    useEffect(() => {
        if(clickedItem)
            setSelectedSidePage(2)
    }, [clickedItem])

    function onItemCreated(){
        reloadItems()
        gotoDefaultSidePage()
    }

    function gotoDefaultSidePage(){
        setClickedItem(null)
        setSelectedSidePage(1)
    }


    let page = <div>Not Found</div>;
    if(selectedPage === 0)
        page = <ItemsList categories={categories} items={items} onItemClick={setClickedItem}/>
    else if(selectedPage === 1)
        page = <div>TODO</div>

    let sidePage = <div>Not Found</div>;
    if(selectedSidePage === 0)
        sidePage = <AddItemForm categories={categories} onSave={onItemCreated} onCancel={() => setSelectedSidePage(1)}/>
    else if(selectedSidePage === 1)
        sidePage = <ActiveList />
    else if(selectedSidePage === 2)
        sidePage = <ItemDetails item={clickedItem} categories={categories} onBackClick={gotoDefaultSidePage}/>

    return (
        <div style={{height: '100%'}}>
            <div className="menu-left"><LeftMenu /></div>
            <div className="main-body">
                {page}
            </div>
            <div className="right-section">{sidePage}</div>
        </div>
    )
}

export default Home