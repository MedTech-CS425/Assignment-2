import './ActiveList.css'

function ActiveList(){
    return <div>Active List</div>
}

export default ActiveList
