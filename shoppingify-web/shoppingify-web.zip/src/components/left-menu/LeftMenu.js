import './LeftMenu.css'

function LeftMenu(props){
    return (<div className="menu">
        <div className="menu-item active">
            <i class="fas fa-list"></i>
        </div>
        <div className="menu-item">
            <i class="fas fa-history"></i>        </div>
        <div className="menu-item">
            <i class="far fa-chart-bar"></i>
        </div>
    </div>)
}

export default LeftMenu
